"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Apple, BriefcaseBusiness, Building2, Bus, CarFront, ChevronRight, Clock3,
  Coffee, GraduationCap, Heart, Home, House, LayoutDashboard, Map, MessageCircle,
  MoreHorizontal, Navigation, Pizza, Search, Settings, ShoppingBasket, Sparkles,
  Star, Sun, UserRound, UsersRound, UtensilsCrossed, WalletCards, X, Zap,
} from "lucide-react";

type Player = {
  money: number; hunger: number; energy: number; health: number; happiness: number;
  week: number; age: number; job: string; salary: number; home: string;
  name: string; appearance: string; trait: string; created: boolean;
};

type Panel = "jobs" | "housing" | "education" | "relationships" | "family" | "vehicles" | "achievements" | "settings" | null;

const initialPlayer: Player = {
  money: 500, hunger: 72, energy: 86, health: 100, happiness: 78,
  week: 1, age: 18, job: "Unemployed", salary: 0, home: "No permanent home",
  name: "Jamie Davis", appearance: "Warm", trait: "Ambitious", created: false,
};

const nav = [
  ["Life", LayoutDashboard], ["Character", UserRound], ["Jobs", BriefcaseBusiness],
  ["Housing", House], ["Education", GraduationCap], ["Relationships", Heart],
  ["Family", UsersRound], ["Vehicles", CarFront], ["Achievements", Star], ["Settings", Settings],
] as const;

const jobs = [
  { title: "Cafe Barista", place: "Corner Cup", pay: 620, req: "No experience required", color: "#d99a61" },
  { title: "Retail Associate", place: "The Market", pay: 690, req: "No experience required", color: "#df6872" },
  { title: "Library Assistant", place: "City Library", pay: 760, req: "High school diploma", color: "#7d76c8" },
  { title: "Junior Developer", place: "Nexus Labs", pay: 1650, req: "Technology certificate", color: "#548eae" },
  { title: "Trainee Mechanic", place: "Northside Auto", pay: 830, req: "Training recommended", color: "#679a77" },
];

const homes = [
  { title: "Temporary Shelter", price: 0, detail: "Shared • Basic comfort" },
  { title: "Room in Oak House", price: 290, detail: "Shared • 1 bedroom" },
  { title: "Maple Studio", price: 520, detail: "Private • Cozy studio" },
  { title: "Riverside Apartment", price: 880, detail: "Private • 2 bedrooms" },
];

const online = [
  { name: "Maya Chen", role: "Medical student", c: "#a86643", initials: "MC" },
  { name: "Leo Brooks", role: "Cafe barista", c: "#3b7880", initials: "LB" },
  { name: "Noah Park", role: "New neighbor", c: "#6465a3", initials: "NP" },
  { name: "Zoe Hart", role: "Freelance artist", c: "#ae596d", initials: "ZH" },
];

function Meter({ label, value, color, icon: Icon }: { label: string; value: number; color: string; icon: typeof Heart }) {
  return <div className="meter"><div className="meter-head"><span><Icon size={13}/>{label}</span><b>{value}%</b></div><div className="meter-track"><i style={{ width: `${value}%`, background: color }}/></div></div>;
}

function Building({ className, label, sub, icon: Icon, tone, onClick }: { className: string; label: string; sub: string; icon: typeof Home; tone: string; onClick?: () => void }) {
  return <button className={`building ${className}`} onClick={onClick} style={{ "--tone": tone } as React.CSSProperties}><span className="building-icon"><Icon size={18}/></span><span><b>{label}</b><small>{sub}</small></span></button>;
}

export default function LifeGame() {
  const [player, setPlayer] = useState<Player>(initialPlayer);
  const [active, setActive] = useState("Life");
  const [panel, setPanel] = useState<Panel>(null);
  const [toast, setToast] = useState("Welcome to Bellweather. Your life starts now.");
  const [messages, setMessages] = useState(2);
  const [ready, setReady] = useState(false);
  const [showCreator, setShowCreator] = useState(false);
  const [characterName, setCharacterName] = useState("Jamie Davis");
  const [appearance, setAppearance] = useState("Warm");
  const [trait, setTrait] = useState("Ambitious");

  useEffect(() => {
    const saved = localStorage.getItem("life-player-v1");
    if (saved) {
      try {
        const restored = { ...initialPlayer, ...JSON.parse(saved) } as Player;
        setPlayer(restored);
        setCharacterName(restored.name);
        setAppearance(restored.appearance);
        setTrait(restored.trait);
        setShowCreator(!restored.created);
      } catch { setShowCreator(true); }
    } else setShowCreator(true);
    setReady(true);
  }, []);
  useEffect(() => { if (ready) localStorage.setItem("life-player-v1", JSON.stringify(player)); }, [player, ready]);

  const initials = player.name.split(" ").filter(Boolean).slice(0, 2).map(part => part[0]).join("").toUpperCase() || "ME";
  const firstName = player.name.split(" ")[0] || "Friend";
  const monthlyExpenses = player.home === "No permanent home" ? 160 : homes.find(h => h.title === player.home)?.price ?? 160;
  const phase = player.age < 25 ? "Young adult" : player.age < 40 ? "Adult" : player.age < 60 ? "Middle age" : "Senior";
  const yearProgress = ((player.week - 1) % 52) / 52 * 100;
  const clamp = (n: number) => Math.max(0, Math.min(100, n));

  function change(patch: Partial<Player>, note: string) {
    setPlayer(p => ({ ...p, ...patch })); setToast(note);
  }
  function createCharacter() {
    const cleanName = characterName.trim();
    if (cleanName.length < 2) { setToast("Give your character a name before continuing."); return; }
    setPlayer(p => ({ ...p, name: cleanName, appearance, trait, created: true }));
    setShowCreator(false);
    setToast(`Welcome to Bellweather, ${cleanName.split(" ")[0]}! Your story starts now.`);
  }
  function activity(kind: string) {
    if (kind === "food") {
      if (player.money < 12) return setToast("You need $12 for groceries.");
      change({ money: player.money - 12, hunger: clamp(player.hunger + 25), happiness: clamp(player.happiness + 2) }, "Fresh groceries! Hunger +25");
    } else if (kind === "work") {
      if (player.job === "Unemployed") { setPanel("jobs"); return; }
      change({ money: player.money + Math.round(player.salary / 4), energy: clamp(player.energy - 20), hunger: clamp(player.hunger - 12) }, `A productive shift earned you $${Math.round(player.salary / 4)}.`);
    } else if (kind === "park") {
      change({ energy: clamp(player.energy - 6), happiness: clamp(player.happiness + 14), health: clamp(player.health + 2) }, "A walk in the park cleared your mind.");
    } else {
      if (player.money < 8) return setToast("You need $8 for the bus fare.");
      change({ money: player.money - 8, happiness: clamp(player.happiness + 5) }, "You explored a new part of Bellweather.");
    }
  }
  function nextWeek() {
    const isNewMonth = player.week % 4 === 0;
    const isBirthday = player.week % 52 === 0;
    const income = isNewMonth ? player.salary : 0;
    const expense = isNewMonth ? monthlyExpenses : 0;
    setPlayer(p => ({ ...p, week: p.week + 1, age: isBirthday ? p.age + 1 : p.age, money: p.money + income - expense, hunger: clamp(p.hunger - 9), energy: clamp(p.energy + 4), happiness: clamp(p.happiness - (p.hunger < 35 ? 5 : 1)), health: clamp(p.health - (p.hunger < 20 ? 4 : 0)) }));
    setToast(isBirthday ? `Happy birthday! You are now ${player.age + 1}.` : isNewMonth ? `Monthly finances settled: +$${income} income, -$${expense} expenses.` : "A new week begins. New possibilities await.");
  }
  function openNav(item: string) {
    setActive(item);
    if (item === "Character") { setCharacterName(player.name); setAppearance(player.appearance); setTrait(player.trait); setShowCreator(true); return; }
    const map: Record<string, Panel> = { Jobs: "jobs", Housing: "housing", Education: "education", Relationships: "relationships", Family: "family", Vehicles: "vehicles", Achievements: "achievements", Settings: "settings" };
    if (map[item]) setPanel(map[item]); else if (item !== "Life") setToast(`${item} profile opened — more opportunities unlock as you live.`);
  }

  const panelContent = useMemo(() => {
    if (panel === "jobs") return { title: "Find your next job", intro: "Build experience, get promoted, or change paths at any time." };
    if (panel === "housing") return { title: "Find a place to call home", intro: "Rent is charged every four weeks. Choose a life you can afford." };
    const names: Record<string, [string,string]> = {
      education: ["Learn & grow", "Courses unlock careers and new possibilities."], relationships: ["Your relationships", "Spend time together to build lasting connections."],
      family: ["Family", "Family planning unlocks at age 25."], vehicles: ["Getting around", "Walk for free, ride the bus, or save up for your own wheels."],
      achievements: ["Life goals", "Optional milestones for every kind of life."], settings: ["Game settings", "Shape your experience in Bellweather."],
    };
    const x = names[panel || "education"]; return { title: x?.[0] || "Life", intro: x?.[1] || "" };
  }, [panel]);

  return <main className="game-shell">
    <aside className="sidebar">
      <div className="logo"><span className="logo-mark">L</span><div><b>LIFE</b><small>YOUR STORY</small></div></div>
      <nav>{nav.map(([name, Icon]) => <button key={name} className={active === name ? "active" : ""} onClick={() => openNav(name)}><Icon size={18}/><span>{name}</span>{name === "Relationships" && <em>2</em>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="mini-avatar">JD</div><div><b>Jamie Davis</b><small>Young adult · {player.age}</small></div><button><MoreHorizontal size={18}/></button></div>
    </aside>

    <section className="content">
      <header className="topbar">
        <div><span className="live-pill"><i/> LIVE WORLD</span><b>BELLWEATHER</b><small>North District · Spring</small></div>
        <div className="clock"><span><Sun size={16}/> Tuesday</span><b>10:42 AM</b><small><Clock3 size={12}/> Year 1 · Week {player.week}</small></div>
        <div className="top-actions"><button aria-label="Search"><Search size={19}/></button><button className="message" aria-label="Messages" onClick={() => setMessages(0)}><MessageCircle size={19}/>{messages > 0 && <i>{messages}</i>}</button><span className="online-count"><i/> 24 online</span></div>
      </header>

      <div className="dashboard">
        <section className="hero-row">
          <div className="welcome"><p>GOOD MORNING, JAMIE</p><h1>Your life is yours<br/>to <em>create.</em></h1><span>You&apos;re 18, with a little money and a world of possibility.<br/>What will you do today?</span><div className="year-line"><div><b>AGE {player.age}</b><small>{phase}</small></div><div className="year-track"><i style={{width: `${yearProgress}%`}}/><span style={{left: `${Math.max(1, yearProgress)}%`}}/></div><div><b>{52 - ((player.week - 1) % 52)} weeks</b><small>until {player.age + 1}</small></div></div></div>
          <div className="portrait-card"><div className="sun-orb"/><div className="portrait-art"><span className="hair"/><span className="face"><i/><b/></span><span className="body"/></div><div className="leaf l1">✦</div><div className="leaf l2">✦</div><span className="level">LEVEL 1</span></div>
        </section>

        <section className="snapshot card">
          <div className="section-title"><div><small>RIGHT NOW</small><h2>Your life at a glance</h2></div><button onClick={() => setToast("Full character statistics are ready to explore.")}>View full stats <ChevronRight size={15}/></button></div>
          <div className="snapshot-grid">
            <div className="stat money"><span><WalletCards size={18}/></span><div><small>MONEY</small><b>${player.money.toLocaleString()}</b><em>{player.money >= 0 ? "+" : ""}$0 this week</em></div></div>
            <div className="stat"><span><BriefcaseBusiness size={18}/></span><div><small>JOB</small><b>{player.job}</b><button onClick={() => setPanel("jobs")}>{player.job === "Unemployed" ? "Find work" : `$${player.salary}/mo`} <ChevronRight size={13}/></button></div></div>
            <div className="stat"><span><Home size={18}/></span><div><small>HOME</small><b>{player.home}</b><button onClick={() => setPanel("housing")}>Find housing <ChevronRight size={13}/></button></div></div>
            <div className="needs"><Meter label="Hunger" value={player.hunger} color="#dc845f" icon={UtensilsCrossed}/><Meter label="Energy" value={player.energy} color="#d9ac3b" icon={Zap}/><Meter label="Health" value={player.health} color="#62a87b" icon={Heart}/><Meter label="Happiness" value={player.happiness} color="#9a74aa" icon={Sparkles}/></div>
          </div>
        </section>

        <div className="main-grid">
          <section className="world card">
            <div className="section-title"><div><small>YOUR NEIGHBORHOOD</small><h2>Explore Bellweather</h2></div><button><Map size={15}/> Open city map</button></div>
            <div className="map-area">
              <span className="road road-a"/><span className="road road-b"/><span className="road road-c"/><span className="river"/>
              <div className="park-zone">NORTH PARK <i>♣</i><i>♣</i></div>
              <Building className="b-grocery" label="THE MARKET" sub="Groceries · Open" icon={ShoppingBasket} tone="#d9a049" onClick={() => activity("food")}/>
              <Building className="b-cafe" label="CORNER CUP" sub="Cafe · Hiring" icon={Coffee} tone="#cc7752" onClick={() => setPanel("jobs")}/>
              <Building className="b-library" label="CITY LIBRARY" sub="Learn · Free" icon={GraduationCap} tone="#768d9c" onClick={() => setPanel("education")}/>
              <Building className="b-homes" label="OAK STREET" sub="Homes available" icon={House} tone="#75a277" onClick={() => setPanel("housing")}/>
              <Building className="b-food" label="SUNNY'S" sub="Food · $$" icon={Pizza} tone="#d05f50" onClick={() => activity("food")}/>
              <div className="you-pin"><span>{initials}</span><b>YOU</b></div>
            </div>
            <div className="quick-actions"><button onClick={() => activity("food")}><ShoppingBasket size={17}/><span><b>Buy groceries</b><small>$12 · +25 hunger</small></span></button><button onClick={() => activity("work")}><BriefcaseBusiness size={17}/><span><b>{player.job === "Unemployed" ? "Find a job" : "Work a shift"}</b><small>{player.job === "Unemployed" ? "5 openings nearby" : `Earn $${Math.round(player.salary / 4)}`}</small></span></button><button onClick={() => activity("park")}><Sun size={17}/><span><b>Visit the park</b><small>Free · +happiness</small></span></button><button onClick={() => activity("explore")}><Bus size={17}/><span><b>Explore downtown</b><small>$8 bus fare</small></span></button></div>
          </section>

          <aside className="right-rail">
            <section className="card people"><div className="section-title"><div><small>AROUND YOU</small><h2>People nearby</h2></div><button>See all</button></div>{online.map((p, i) => <div className="person" key={p.name}><span className="avatar" style={{background:p.c}}>{p.initials}</span><div><b>{p.name}</b><small>{p.role}</small></div><i className={i < 3 ? "on" : ""}/><button onClick={() => setToast(`You waved to ${p.name}. A new connection begins!`)}><MessageCircle size={15}/></button></div>)}</section>
            <section className="card story"><div className="section-title"><div><small>YOUR STORY</small><h2>Next chapter</h2></div></div><div className="story-step done"><i>✓</i><span><b>Welcome to Bellweather</b><small>You arrived with $500</small></span></div><div className={`story-step ${player.home !== "No permanent home" ? "done" : ""}`}><i>{player.home !== "No permanent home" ? "✓" : "2"}</i><span><b>Find a place to live</b><small>{player.home !== "No permanent home" ? player.home : "Explore available housing"}</small></span></div><div className={`story-step ${player.job !== "Unemployed" ? "done" : ""}`}><i>{player.job !== "Unemployed" ? "✓" : "3"}</i><span><b>Earn your first paycheck</b><small>{player.job !== "Unemployed" ? `Working as ${player.job}` : "Find a job that suits you"}</small></span></div></section>
          </aside>
        </div>
        <footer><span>Every choice writes your story.</span><button onClick={nextWeek}>Continue to next week <ChevronRight size={16}/></button></footer>
      </div>
    </section>

    {ready && showCreator && <div className="creator-overlay">
      <section className="creator-card">
        {player.created && <button className="creator-close" onClick={() => setShowCreator(false)} aria-label="Close character editor"><X size={20}/></button>}
        <div className="creator-intro">
          <span className="option-label">OPTION B · CREATE YOUR OWN CHARACTER</span>
          <div className={`creator-preview ${appearance.toLowerCase()}`}><span className="preview-hair"/><span className="preview-face"/><span className="preview-shirt"/></div>
          <small>STEP 1 OF YOUR LIFE</small>
          <h2>Create your character first</h2>
          <p>This character represents you in Bellweather. Choose who you want to be before your story begins.</p>
          <div className="start-facts"><span><b>18</b> Starting age</span><span><b>$500</b> Starting money</span><span><b>∞</b> Possible lives</span></div>
        </div>
        <div className="creator-form">
          <div className="instruction"><i>1</i><div><b>Name your character</b><small>This name is shown to other players.</small></div></div>
          <label className="name-field"><span>FULL NAME</span><input value={characterName} maxLength={28} onChange={e => setCharacterName(e.target.value)} placeholder="Enter a name" autoFocus/></label>
          <div className="instruction"><i>2</i><div><b>Choose a look</b><small>You can change your appearance later.</small></div></div>
          <div className="choice-grid looks">{["Warm","Classic","Bold"].map(item => <button key={item} className={appearance === item ? "selected" : ""} onClick={() => setAppearance(item)}><span className={`look-dot ${item.toLowerCase()}`}/><b>{item}</b>{appearance === item && <i>✓</i>}</button>)}</div>
          <div className="instruction"><i>3</i><div><b>Pick a starting trait</b><small>This describes how you want to approach life.</small></div></div>
          <div className="choice-grid traits">{[["Ambitious","Build a big future"],["Social","Connect with people"],["Creative","Follow your curiosity"]].map(([item, sub]) => <button key={item} className={trait === item ? "selected" : ""} onClick={() => setTrait(item)}><Sparkles size={15}/><span><b>{item}</b><small>{sub}</small></span></button>)}</div>
          <div className="creator-tip"><Sparkles size={15}/><span><b>What happens next?</b>You&apos;ll enter the city at age 18 with $500. Your first goals are to find housing, food, and a way to earn money.</span></div>
          <button className="begin-life" onClick={createCharacter}>{player.created ? "Save character" : "Create character & begin life"}<ChevronRight size={17}/></button>
        </div>
      </section>
    </div>}

    {toast && <div className="toast"><Sparkles size={16}/><span>{toast}</span><button onClick={() => setToast("")}><X size={15}/></button></div>}

    {panel && <div className="overlay" onMouseDown={() => setPanel(null)}><aside className="drawer" onMouseDown={e => e.stopPropagation()}><button className="close" onClick={() => setPanel(null)}><X size={20}/></button><small className="eyebrow">BELLWEATHER OPPORTUNITIES</small><h2>{panelContent.title}</h2><p>{panelContent.intro}</p>
      {panel === "jobs" && <div className="option-list">{jobs.map(job => <button className="option" key={job.title} onClick={() => { change({job: job.title, salary: job.pay}, `Congratulations! You're now a ${job.title}.`); setPanel(null); }}><span className="option-icon" style={{background:job.color}}><BriefcaseBusiness size={19}/></span><div><b>{job.title}</b><small>{job.place} · {job.req}</small></div><em>${job.pay}/mo</em></button>)}<button className="quit-job" disabled={player.job === "Unemployed"} onClick={() => {change({job:"Unemployed",salary:0},"You left your job. A new path awaits.");setPanel(null);}}>Quit current job</button></div>}
      {panel === "housing" && <div className="option-list">{homes.map(home => {const can = player.money >= home.price; return <button disabled={!can} className="option" key={home.title} onClick={() => {change({home:home.title,money:player.money-home.price},`You moved into ${home.title}. Welcome home!`);setPanel(null);}}><span className="option-icon home-icon"><House size={19}/></span><div><b>{home.title}</b><small>{home.detail}</small></div><em>{home.price ? `$${home.price}/mo` : "Free"}</em></button>})}</div>}
      {panel && !["jobs","housing"].includes(panel) && <div className="feature-panel">{panel === "education" && <><div className="feature-icon"><GraduationCap/></div><b>City Skills Academy</b><span>Technology certificate · 12 weeks · $240</span><button onClick={() => {if(player.money>=240){change({money:player.money-240},"You enrolled! Your learning journey has begun.");setPanel(null)}else setToast("Save $240 to enroll in this course.")}}>Enroll in a course</button></>}{panel === "relationships" && <><div className="feature-icon"><Heart/></div><b>4 people nearby</b><span>Meet people in the world and build friendships naturally.</span><button onClick={() => {setPanel(null);setToast("Visit a place on the map to meet someone new.")}}>Meet someone</button></>}{panel === "family" && <><div className="feature-icon"><UsersRound/></div><b>{player.age < 25 ? "A future chapter" : "Ready when you are"}</b><span>{player.age < 25 ? `Family planning unlocks in ${25-player.age} years.` : "Build a family when the moment feels right."}</span></>}{panel === "vehicles" && <><div className="feature-icon"><CarFront/></div><b>City bicycle</b><span>$180 · No fuel costs · Easy maintenance</span><button onClick={() => setToast("Keep saving — vehicle ownership is coming soon!")}>Browse vehicles</button></>}{panel === "achievements" && <div className="goals"><span>◈ First Paycheck</span><span>◇ A Place of My Own</span><span>◇ Millionaire</span><span>◇ Lifelong Friend</span><span>◇ Dream Career</span></div>}{panel === "settings" && <><div className="setting"><span>World notifications</span><input type="checkbox" defaultChecked/></div><div className="setting"><span>Safe chat filter</span><input type="checkbox" defaultChecked/></div><button className="reset" onClick={() => {setPlayer(initialPlayer);setCharacterName(initialPlayer.name);setAppearance(initialPlayer.appearance);setTrait(initialPlayer.trait);localStorage.removeItem("life-player-v1");setPanel(null);setShowCreator(true);setToast("Create your character to begin a fresh life.")}}>Restart this life</button></>}</div>}
    </aside></div>}
  </main>;
}
